﻿namespace API.Control.Services.Interfaces
{
    public interface IAppxPackageService
    {
        Task<IEnumerable<AppxPackageReadDTO>> GetAllAsync();
        Task<AppxPackageReadDTO?> GetByIdAsync(Guid id);
        Task<AppxPackageReadDTO> CreateAsync(AppxPackageCreateDTO dto);
        Task<AppxPackageReadDTO?> UpdateAsync(Guid id, AppxPackageUpdateDTO dto);
        Task<bool> DeleteAsync(Guid id);
    }
}