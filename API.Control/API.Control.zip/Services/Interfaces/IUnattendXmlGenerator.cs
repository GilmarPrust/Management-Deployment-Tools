﻿namespace API.Control.Services.Interfaces
{
    public interface IUnattendXmlGenerator
    {
    }
}
