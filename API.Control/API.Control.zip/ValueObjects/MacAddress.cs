﻿namespace API.Control.ValueObjects
{
    /// <summary>
    /// Representa um endereço MAC válido.
    /// </summary>
    public sealed class MacAddress
    {
        public string Value { get; } = string.Empty;

        // Construtor padrão privado para o EF Core
        private MacAddress() { }

        public MacAddress(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                throw new ArgumentException("MAC address não pode ser vazio.", nameof(value));

            if (!Regex.IsMatch(value, @"^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$"))
                throw new ArgumentException("Formato de MAC address inválido.", nameof(value));

            Value = value.ToUpper();
        }

        public override string ToString() => Value;

        public override bool Equals(object? obj) => obj is MacAddress other && Value == other.Value;

        public override int GetHashCode() => Value.GetHashCode();
    }
}