﻿namespace API.Control.Entities
{
    /// <summary>
    /// Entidade base para todas as entidades do domínio, fornecendo propriedades comuns.
    /// </summary>
    public abstract class BaseEntity
    {
        /// <summary>
        /// Identificador único da entidade.
        /// </summary>
        public Guid Id { get; init; } = Guid.NewGuid();

        /// <summary>
        /// Data de criação da entidade.
        /// </summary>
        public DateTime CreatedAt { get; init; } = DateTime.UtcNow;

        /// <summary>
        /// Data da última atualização da entidade.
        /// </summary>
        public DateTime? UpdatedAt { get; set; }

        /// <summary>
        /// Data de exclusão lógica da entidade.
        /// </summary>
        public DateTime? DeletedAt { get; set; }

        /// <summary>
        /// Indica se a entidade está habilitada (soft delete).
        /// </summary>
        public bool Enabled { get; set; } = true;
    }
}
