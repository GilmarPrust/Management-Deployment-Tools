﻿namespace API.Control.Entities
{
    /// <summary>
    /// Representa um firmware associado a um modelo de dispositivo.
    /// </summary>
    public class Firmware : BaseEntity
    {
        /// <summary>
        /// Nome do arquivo do firmware.
        /// </summary>
        [Required, StringLength(100)]
        public required string FileName { get; init; }

        /// <summary>
        /// Versão do firmware.
        /// </summary>
        [Required, StringLength(50)]
        public required string Version { get; init; }

        /// <summary>
        /// Caminho de origem do firmware.
        /// </summary>
        [Required, StringLength(250)]
        public required string Source { get; init; }

        /// <summary>
        /// Hash do arquivo do firmware.
        /// </summary>
        [Required, StringLength(64)]
        public required string Hash { get; init; }

        /// <summary>
        /// Construtor vazio para o Entity Framework.
        /// </summary>
        public Firmware() { }

        /// <summary>
        /// ID do modelo de dispositivo ao qual o firmware está vinculado.
        /// </summary>
        [Required]
        public required Guid DeviceModelId { get; init; }

        /// <summary>
        /// Modelo de dispositivo associado ao firmware.
        /// </summary>
        public virtual DeviceModel DeviceModel { get; init; } = null!;
    }
}
