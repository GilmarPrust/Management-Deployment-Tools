<#
+---------------------------------------------------------------------------------------------------------------------+
    .Description
        Get-DriverPackCatalog
        Filename: Get-DriverPackCatalog.ps1
        Created by: Gilmar Prust
    
    .DESCRIPTION
        Obtem os catalogos, e retorna um PSCustonObject.

    .OUTPUTS
        Returns ArrayList of Devices @{ Manufacturer=""; Model=""; Types=""; OS=""; Version=""; Link=""; Hash="" }
+---------------------------------------------------------------------------------------------------------------------+
#>
using module .\Classes\DriverPack.psm1

#Define Global Variables.
New-Variable -Name DeployRoot -Value "$($PSScriptRoot)" -Scope Global -Force -Option ReadOnly
Set-Location $DeployRoot -Verbose

#IMPORT MODULES
Import-Module .\Modules\Download -Force -Global -ErrorAction Stop -Verbose
Import-Module .\Modules\DeviceModelCatalog -Force -Global -ErrorAction Stop -Verbose
Import-Module .\Modules\XmlContent -Force -Global -ErrorAction Stop -Verbose
Import-Module .\Modules\Control -Force -Global -ErrorAction Stop -Verbose

function Main {
   
    begin {
        ###
        Write-Host "Getting all driverpack catalog... " -ForegroundColor Magenta -NoNewline
        $catalogSettings = (Get-Settings).Catalog.DriverPacks
        [DriverPackCatalog]::Initialize()
    }
    process {
        ###
        foreach ($item in $catalogSettings) {

            $devicesCatalog = Get-XmlContent -Url $item.Link | Get-DriverPackCatalog -Manufacturer $item.Manufacturer

            $devicesCatalog | ForEach-Object {

                [DriverPackCatalog]::Add( 
                    [DriverPack]::new( 
                        $_.Manufacturer, 
                        $_.Model, 
                        $_.Types, 
                        $_.OS,
                        $_.Version, 
                        $_.Link, 
                        $_.Hash)
                ) | Out-Null
            }
        }
    }
    end {
        ###
        $catalog = [DriverPackCatalog]::GetAll()
        Write-Host "Done. $($catalog.Count) Devices" -ForegroundColor Green
        return $catalog
        <#
            IsPublic IsSerial Name         BaseType
            -------- -------- ------------ --------
            True     True     DriverPack[] System.Array
        #>
    }
}
Main
