<#
+----------------------------------------------------------------------------------------+
    .DESCRIPTION
    Device Module
	Created by: Gilmar Prust
	Filename:   Device.psm1
+----------------------------------------------------------------------------------------+
#>

class Device {
    [string]$Guid
    [string]$ComputerName
    [string]$SerialNumber
    [string]$MACAddress
    
    Device([string]$Guid, [String]$ComputerName, [String]$SerialNumber, [string]$MACAddress) {
        $this.Guid            = $Guid
        $this.ComputerName    = $ComputerName
        $this.SerialNumber    = $SerialNumber
        $this.MACAddress      = $MACAddress
    }

    Device([String]$ComputerName, [String]$SerialNumber, [string]$MACAddress) {
        $this.Guid            = (New-Guid).Guid
        $this.ComputerName    = $ComputerName
        $this.SerialNumber    = $SerialNumber
        $this.MACAddress      = $MACAddress
    }

    Device([String]$SerialNumber, [string]$MACAddress) {
        $this.Guid            = (New-Guid).Guid
        $this.ComputerName    = (New-ComputerName)
        $this.SerialNumber    = $SerialNumber
        $this.MACAddress      = $MACAddress
    }
}

class DeviceList {

    static [System.Collections.Generic.List[Device]] $Devices

    static [void] Initialize() {
        
        [DeviceList]::Devices = [System.Collections.Generic.List[Device]]::new()
    }

    static [void] Add([Device]$Device) {
        
        [DeviceList]::Devices.Add($Device)
    } 

    static [void] AddRange($Devices) {
        
        $Devices | ForEach-Object {

            [DeviceList]::Devices.Add( 
                [Device]::new( 
                    $_.Guid,
                    $_.ComputerName,
                    $_.SerialNumber,
                    $_.MacAddress
                )
            )
        }
    }

    static [bool] Exists($DeviceInfo) {

        $match = [System.Predicate[Device]] {
            param ($device)
            $device.SerialNumber -eq $DeviceInfo.SerialNumber -or
            $device.MacAddress -eq $DeviceInfo.MacAddress -or 
            $device.ComputerName -eq $DeviceInfo.ComputerName
        }
        return [DeviceList]::Devices.Exists($match)
    } 
}


function Import-Devices {
    <##>
    Import-Module $DeployRoot\Modules\Control
    
    return Import-JsonDevices
}

function Save-Devices {
    <##>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNullOrEmpty()]
        $InputObject
    )

    Import-Module  $DeployRoot\Modules\Control

    Save-JsonDevices -Content $InputObject
}


function Get-Device {
    <#
        .DESCRIPTION
        Obtem informações do dispositivo no banco de dados.
        Se não existir, cria um.

        .OUTPUTS
        Return Device...
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        $HardwareInfo
    )

    $device = Get-Devices | Where-Object { $_.SerialNumber -eq $HardwareInfo.SerialNumber -or $_.MacAddress -eq $HardwareInfo.Network.MacAddress }

    if ($null -eq $device) {
        $device = New-Device -HardwareInfo $HardwareInfo
    }
    
    return $device
}

function Get-Devices {
    <##>
    [DeviceList]::Initialize()

    [DeviceList]::AddRange(@(Import-Devices))

    ### Convert to PSCustomObject.
    $Devices = [DeviceList]::Devices | ForEach-Object { 

        [PSCustomObject]@{ 
            Guid            = $_.Guid;
            ComputerName    = $_.ComputerName; 
            SerialNumber    = $_.SerialNumber; 
            MacAddress      = $_.MacAddress
        }
    }
    return $Devices
}

function New-Device {
    <#
        .DESCRIPTION
        Cria um novo Device.

        .OUTPUTS
        Return ComputerName, Profile...
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        $HardwareInfo
    )

    begin {
        <##>
        Import-Module $DeployRoot\Modules\Control

        [DeviceList]::Initialize()

        [DeviceList]::AddRange(@(Import-Devices))

        <# Verifica se modelo e tipo já existe. #>
        if ([DeviceList]::Exists($DeviceInfo)) {
            Throw "Device alread exist."
        }
        
    }
    process {
        <##>
        [DeviceList]::Devices.Add(
            [Device]::new( 
                $HardwareInfo.SerialNumber, 
                $HardwareInfo.Network.MACAddress
            )
        )
    }
    end {
        <##>
        Save-Devices -InputObject ([DeviceList]::Devices)

        return [DeviceList]::Devices | Select-Object -Last 1
    }
}

function New-ComputerName {
    
    <#
        "KIOSK", "DSKTP", "NOTBK", "TABLT", "SERVR"
    #>
    $hex = -join ((0..9) + (10..15) | Get-Random -Count 4 | ForEach-Object { "{0:X}" -f $_ })

    return -join ('DSKTP', '-', $hex)
}


Export-ModuleMember -Function Get-Device
Export-ModuleMember -Function New-Device



# SIG # Begin signature block
# MIIFlAYJKoZIhvcNAQcCoIIFhTCCBYECAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUYevSz1LXrWMEGmzNepreWUdB
# 5XCgggMiMIIDHjCCAgagAwIBAgIQONirzSpNl5FNggQlpn5yyDANBgkqhkiG9w0B
# AQsFADAnMSUwIwYDVQQDDBxQb3dlclNoZWxsIENvZGUgU2lnbmluZyBDZXJ0MB4X
# DTIzMDcxNDE1NTUxN1oXDTI0MDcxNDE2MTUxN1owJzElMCMGA1UEAwwcUG93ZXJT
# aGVsbCBDb2RlIFNpZ25pbmcgQ2VydDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCC
# AQoCggEBAL/rqq9BFlGt8bVmQ6EqY43B8W3d2b82C/QN8O37QTChQKUPws+osX1f
# tj9MPdL93WC/XEPqvUiwqPtvBS63JinOJGATsxXh/+fcHCbvJnCestdrZ36VnJJ+
# rvslUBvorv5ynfpBSZRbCuA9aK06rBXksGTbu1wLdGc3oezK7iKymqYwIilFxqz8
# FnliKSbiUWhQmpGxx9RTjZ4YP6YItETeeDMRFGBVp6wlW+qXt6fV7VfqwRkpFCNJ
# YBO9j1Cpz/WcIjoXIeorb9iY5UEsNlLzIcJV0eqJlsvvqqyK07ITKug1OK/OXsYk
# ziA9WWLmpsvv0jRQYHFwXpcx2pwmr7UCAwEAAaNGMEQwDgYDVR0PAQH/BAQDAgeA
# MBMGA1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBQ3wm3NMuMjb8eeEE5cDN2+
# 4M0FOzANBgkqhkiG9w0BAQsFAAOCAQEAEQsmQjGeMB04f0awcyggFRT988/9EN80
# bzdIWYdJFKJ3Nu2N/vKZOaSBF7AAMrNpYZGFVUgZ8wkfobw12RnH+Lz9cyt+rCSS
# TBfMyIZfoVT9sAu7NQV5cufqH82ObysqoZa3PbniXvDE+PaP1ceWje1ONmFdtr8X
# Ffkv0QFmKeH2x4cpzrJBBD58GI3XssUD2xxtHZntC98VOy0Vk4eQQZCXr42m2C3Q
# lMZby+vvm179rkn8icFkDMlQ81Im6DBSSKDP5AqWGfI5d+54ACFayHiztSS0lyl6
# OBo8+fK5kJXoTqSR2F7oh4hvFvfaBanGWmYHwcXo1yKRX2jD80/RgDGCAdwwggHY
# AgEBMDswJzElMCMGA1UEAwwcUG93ZXJTaGVsbCBDb2RlIFNpZ25pbmcgQ2VydAIQ
# ONirzSpNl5FNggQlpn5yyDAJBgUrDgMCGgUAoHgwGAYKKwYBBAGCNwIBDDEKMAig
# AoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgEL
# MQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUoCKK/wgGQkU0G6YIqMv4
# kx09lmcwDQYJKoZIhvcNAQEBBQAEggEAHhFmSqNnGiUokoAqG+89HfYszpEI2c9i
# wT+uhN6vmVX953wg37r7MnGL3Dr5sTGwkjzYsCOSfYNzYP6cqWSeUzE3CyUGinr5
# 9zapN3dVvsaKyjzaz9yt4c7/loXygBm0Rx0ZPFoPxA3lIMPpHVXMVg7BZ0piyVzV
# PbYVw9leHo8xDcDnmmVfuLWNQNlzLxCbrIH5Hm3G3Lv/X8wf2b4/5iAJBXdw9WbO
# 30BsRLlBoWoPSxUto+fZy1I7Ja5oA2Pf27MGLcN37usO/qMly4ozwLm0yZ6Za7gl
# 8t2haaRV7gs2JVSWMDBvm4WyTUwmhybgowFQofaXiw402/E0ajQZyQ==
# SIG # End signature block
