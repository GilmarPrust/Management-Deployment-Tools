<#
+----------------------------------------------------------------------------------------+
    .DESCRIPTION
    DriverPack Module
    Created by: Gilmar Prust
    Filename: DriverPack.psm1
+----------------------------------------------------------------------------------------+
#>

class DriverPack {
    [string]$DeviceModelGuid
    [string]$FileName
    [string]$OS
    [string]$Version
    [string]$Source
    [string]$Hash
    [bool]$Enabled
    
    DriverPack([string]$DeviceModelGuid, [String]$FileName, [String]$OS, [String]$Version, [string]$Source, [string]$Hash, [bool]$Enabled ) {
        $this.DeviceModelGuid = $DeviceModelGuid
        $this.FileName        = $FileName
        $this.OS              = $OS
        $this.Version         = $Version
        $this.Source          = $Source
        $this.Hash            = $Hash
        $this.Enabled         = $Enabled
    }
}

class DriverPackList {

    static [System.Collections.Generic.List[DriverPack]] $DriverPacks

    static [void] Initialize() {
        
        [DriverPackList]::DriverPacks = [System.Collections.Generic.List[DriverPack]]::new()
    }

    static [void] Add([DriverPack]$DriverPack) {
        
        [DriverPackList]::DriverPacks.Add($DriverPack)
    } 

    static [void] AddRange($DriverPacks) {
        
        $DriverPacks | ForEach-Object {

            [DriverPackList]::DriverPacks.Add( 
                [DriverPack]::new( 
                    $_.DeviceModelGuid,
                    $_.FileName,
                    $_.OS,
                    $_.Version,
                    $_.Source,
                    $_.Hash,
                    $_.Enabled
                )
            )
        }
    } 

    static [bool] Exists($DeviceModelGuid, $Object) {

        $match = [System.Predicate[DriverPack]] {
            param ($driverpack)
            $driverpack.DeviceGuid -eq $DeviceModelGuid -and $driverpack.OS -eq $Object.OS
        }
        return [DriverPackList]::DriverPacks.Exists($match)
    } 
}

function Get-DriverPacks {
    <##>
    [DriverPackList]::Initialize()

    [DriverPackList]::AddRange(@(Import-DriverPacks))

    ### Converto to PSCustomObject.
    $DriverPacks = [DriverPackList]::DriverPacks | ForEach-Object { 

        [PSCustomObject]@{ 
            DeviceModelGuid = $_.DeviceModelGuid
            FileName        = $_.FileName
            OS              = $_.OS
            Version         = $_.Version
            Source          = $_.Source
            Hash            = $_.Hash
            Enabled         = $_.Enabled
        }
    }
    return $DriverPacks
}

function Get-DriverPack {
    <#
        .DESCRIPTION
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$DeviceModelGuid
    )

    $driverpack = Import-DriverPacks | Where-Object { $_.DeviceModelGuid -eq $DeviceModelGuid -and $_.Enabled -eq $true }

    return $driverpack
}

function Import-DriverPacks {
    <##>
    Import-Module .\Modules\Control
    
    return Import-JsonDriverPacks
}

function Save-DriverPacks {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNullOrEmpty()]
        $InputObject
    )

    Import-Module .\Modules\Control

    Save-JsonDriverPacks -Content $InputObject
}

function Add-DriverPack {
    <#
        .DESCRIPTION
        Adiciona um item em DriverPack.json.
        Este item precisa estar vinculado a um dispositivo de DeviceModels.json.

        .PARAMETER DeviceGuid
        Especifique o modelo de dispositivo obtido de DeviceModels.json.

        .PARAMETER InputObject
        Especifique o item do catalogo obtido de Get-DeviceModelCatalog.
    #>
    [CmdletBinding()]
    param (
        [ValidateNotNullOrEmpty()]
        [Parameter(Mandatory)]
        [string]$DeviceModelGuid,
        [Object]$InputObject
    )
    
    begin {
        <##>
        [DriverPackList]::Initialize()

        [DriverPackList]::AddRange(@(Import-DriverPacks))

        <# Verifica se Hash do arquivo já existe. #>
        if ([DriverPackList]::Exists($DeviceModelGuid, $InputObject)) {
            Throw "DriverPack alread exist."
        }

        Import-Module .\Modules\Download

        $filename = Split-Path -Path $InputObject.Link -Leaf
        $fullfilepath = "$($DeployRoot)\DriverPacks\$($filename)"

    }
    process {
        <##>
        ### Download DriverPack
        Download -Url $InputObject.Link -Destination $fullfilepath -Hash $InputObject.Hash | Out-Null

        [DriverPackList]::Add(
            [DriverPack]::new( 
                $DeviceModelGuid, 
                $filename, 
                $InputObject.OS,
                $InputObject.Version,
                "\DriverPacks\$($filename)",
                $InputObject.Hash,
                $True
            )
        )
    }
    end {
        <##> 
        ### Save DriverPack.
        Save-DriverPacks -InputObject ([DriverPackList]::DriverPacks)

        return [DriverPackList]::DriverPacks | Select-Object -Last 1
    }
}


Export-ModuleMember -Function Add-DriverPack
Export-ModuleMember -Function Get-DriverPack
Export-ModuleMember -Function Get-DriverPacks


# SIG # Begin signature block
# MIIFlAYJKoZIhvcNAQcCoIIFhTCCBYECAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUYevSz1LXrWMEGmzNepreWUdB
# 5XCgggMiMIIDHjCCAgagAwIBAgIQONirzSpNl5FNggQlpn5yyDANBgkqhkiG9w0B
# AQsFADAnMSUwIwYDVQQDDBxQb3dlclNoZWxsIENvZGUgU2lnbmluZyBDZXJ0MB4X
# DTIzMDcxNDE1NTUxN1oXDTI0MDcxNDE2MTUxN1owJzElMCMGA1UEAwwcUG93ZXJT
# aGVsbCBDb2RlIFNpZ25pbmcgQ2VydDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCC
# AQoCggEBAL/rqq9BFlGt8bVmQ6EqY43B8W3d2b82C/QN8O37QTChQKUPws+osX1f
# tj9MPdL93WC/XEPqvUiwqPtvBS63JinOJGATsxXh/+fcHCbvJnCestdrZ36VnJJ+
# rvslUBvorv5ynfpBSZRbCuA9aK06rBXksGTbu1wLdGc3oezK7iKymqYwIilFxqz8
# FnliKSbiUWhQmpGxx9RTjZ4YP6YItETeeDMRFGBVp6wlW+qXt6fV7VfqwRkpFCNJ
# YBO9j1Cpz/WcIjoXIeorb9iY5UEsNlLzIcJV0eqJlsvvqqyK07ITKug1OK/OXsYk
# ziA9WWLmpsvv0jRQYHFwXpcx2pwmr7UCAwEAAaNGMEQwDgYDVR0PAQH/BAQDAgeA
# MBMGA1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBQ3wm3NMuMjb8eeEE5cDN2+
# 4M0FOzANBgkqhkiG9w0BAQsFAAOCAQEAEQsmQjGeMB04f0awcyggFRT988/9EN80
# bzdIWYdJFKJ3Nu2N/vKZOaSBF7AAMrNpYZGFVUgZ8wkfobw12RnH+Lz9cyt+rCSS
# TBfMyIZfoVT9sAu7NQV5cufqH82ObysqoZa3PbniXvDE+PaP1ceWje1ONmFdtr8X
# Ffkv0QFmKeH2x4cpzrJBBD58GI3XssUD2xxtHZntC98VOy0Vk4eQQZCXr42m2C3Q
# lMZby+vvm179rkn8icFkDMlQ81Im6DBSSKDP5AqWGfI5d+54ACFayHiztSS0lyl6
# OBo8+fK5kJXoTqSR2F7oh4hvFvfaBanGWmYHwcXo1yKRX2jD80/RgDGCAdwwggHY
# AgEBMDswJzElMCMGA1UEAwwcUG93ZXJTaGVsbCBDb2RlIFNpZ25pbmcgQ2VydAIQ
# ONirzSpNl5FNggQlpn5yyDAJBgUrDgMCGgUAoHgwGAYKKwYBBAGCNwIBDDEKMAig
# AoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgEL
# MQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUoCKK/wgGQkU0G6YIqMv4
# kx09lmcwDQYJKoZIhvcNAQEBBQAEggEAHhFmSqNnGiUokoAqG+89HfYszpEI2c9i
# wT+uhN6vmVX953wg37r7MnGL3Dr5sTGwkjzYsCOSfYNzYP6cqWSeUzE3CyUGinr5
# 9zapN3dVvsaKyjzaz9yt4c7/loXygBm0Rx0ZPFoPxA3lIMPpHVXMVg7BZ0piyVzV
# PbYVw9leHo8xDcDnmmVfuLWNQNlzLxCbrIH5Hm3G3Lv/X8wf2b4/5iAJBXdw9WbO
# 30BsRLlBoWoPSxUto+fZy1I7Ja5oA2Pf27MGLcN37usO/qMly4ozwLm0yZ6Za7gl
# 8t2haaRV7gs2JVSWMDBvm4WyTUwmhybgowFQofaXiw402/E0ajQZyQ==
# SIG # End signature block