
class Device {

    [string]$Manufacturer
    [string]$Model
    [string[]]$Types = @()
    
    Device([String]$Manufacturer, [String]$Model, [string[]]$Types) {
        $this.Manufacturer = $Manufacturer
        $this.Model        = $Model
        $this.Types        = $Types
    }
}


class DeviceList {

    static [System.Collections.Generic.List[Device]] $DeviceModels

    ### Método para inicializar a lista de Devices.
    static [void] Initialize() {
        
        [DeviceList]::DeviceModels = [System.Collections.Generic.List[Device]]::new()
    }

    ### Método para obter todos os Devices.
    static [Device[]] GetAll() {
        return [DeviceList]::DeviceModels
    }

    ### Método para adicionar um Device na Lista.
    static [void] Add([Device]$Model) {
        
        [DeviceList]::DeviceModels.Add($Model)
    } 
}
