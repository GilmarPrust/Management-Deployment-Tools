<#
+----------------------------------------------------------------------------------------+
    .DESCRIPTION
    Deploy Module
	Created by: Gilmar Prust
	Filename:   Deploy.psm1
+----------------------------------------------------------------------------------------+
#>
function Get-DeployHardwareInfo {
    <#
        .DESCRIPTION
    #>

    ### IMPORT MODULE
    Import-Module $DeployRoot\Modules\Hardware -Force

    $hardwareinfo = Get-HardwareInfo
    if ($null -eq $hardwareinfo) { Throw "DeviceModel not found, please use Add-DeviceModel.ps1" }
    
    <#
        Check network state before continue.
    #>

    return $hardwareinfo
}
function Get-DeployDeviceModelInfo {
    <#
        .DESCRIPTION
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        $HardwareInfo
    )
    ### IMPORT MODULE
    Import-Module $DeployRoot\Modules\DeviceModels -Force

    $devicemodel = Get-DeviceModel -HardwareInfo $HardwareInfo
    if ($null -eq $devicemodel) { Throw "DeviceModel not found, please use Add-DeviceModel.ps1" }
    #$devicemodel = Add-DeviceModel -HardwareInfo $hardwareinfo

    return $devicemodel
}
function Get-DeployFirmwareInfo {
    <#
        .DESCRIPTION
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        $DeviceModelGuid
    )
    ### IMPORT MODULE
    Import-Module $DeployRoot\Modules\Firmware -Force

    $firmware = Get-Firmware -DeviceModelGuid $DeviceModelGuid
    
    return $firmware
}
function Get-DeployDriverPackInfo {
    <#
        .DESCRIPTION
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        $DeviceModelGuid
    )
    ### IMPORT MODULE
    Import-Module $DeployRoot\Modules\DriverPack -Force

    $driverPack = Get-DriverPack -DeviceModelGuid $DeviceModelGuid
    
    return $driverPack
}
function Get-DeployDeviceInfo {
    <#
        .DESCRIPTION
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        $HardwareInfo
    )
    ### IMPORT MODULE
    Import-Module $DeployRoot\Modules\Device -Force

    $device = Get-Device -HardwareInfo $HardwareInfo
    
    return $device
}
function Get-DeployDeviceProfileInfo {
    <#
        .DESCRIPTION
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        $DeviceGuid
    )
    ### IMPORT MODULE
    Import-Module $DeployRoot\Modules\Profiles -Force

    $deviceprofile = Get-DeviceProfile -DeviceGuid $DeviceGuid
    
    return $deviceprofile
}
function Get-DeployDeviceIDOfficeInfo {
    <#
        .DESCRIPTION
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        $DeviceGuid
    )
    ### IMPORT MODULE
    Import-Module $DeployRoot\Modules\Office365 -Force

    $devicePidOffice = Get-DeviceIDOffice -DeviceGuid $DeviceGuid
    
    return $devicePidOffice
}
function Get-DeployApplicationsInfo {
    <#
        .DESCRIPTION
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        $ProfileApps,
        $Device,
        $DeviceModel
    )
    ### IMPORT MODULE
    Import-Module $DeployRoot\Modules\Application -Force

    $applications = Get-DeployApplications -ProfileApps $ProfileApps -Device $Device -DeviceModel $DeviceModel
    
    return $applications
}
function Get-DeployImageInfo {
    <#
        .DESCRIPTION
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        $Guid
    )
    ### IMPORT MODULE
    Import-Module $DeployRoot\Modules\Image -Force

    $image = Get-Image -Guid $Guid
    
    return $image
}
function Get-DeployDiskInfo {
    <#
        .DESCRIPTION
    #>

    ### IMPORT MODULE
    Import-Module $DeployRoot\Modules\Disk -Force

    $disk = $null
    ### if not running WinPE select manual disk.
    if (Test-Path -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WinPE") {
        $disk = Get-DeployDisk -Auto
    } else {
        $disk = Get-DeployDisk | Out-GridView -OutputMode Single -Title "Select disk"
    }
    if ($null -eq $disk) { Throw "Disk is null." }

    return $disk 
}
function Get-DeployirmwareTypeInfo {
    <#
        .DESCRIPTION
    #>
    ### IMPORT MODULE
    Import-Module $DeployRoot\Modules\Control -Force

    ### if not running WinPE select manual disk.
    $firmwareType = (Import-JsonSettings).FirmwareType

    return $firmwareType
}
function Get-DeployInfo {
    <#
        .DESCRIPTION
    #>
    
    #Import-Module $DeployRoot\Modules\Copy -Force

    $deployInfo = New-Object -TypeName PSObject

    ### Obtem informações do hardware.
    $deployInfo | Add-Member -MemberType NoteProperty -Name Hardware -Value (Get-DeployHardwareInfo)

    ### Get DeviceModel.
    $deployInfo | Add-Member -MemberType NoteProperty -Name DeviceModel -Value (Get-DeployDeviceModelInfo -HardwareInfo $deployInfo.Hardware)
    
    ### Get Firmware.
    $deployInfo | Add-Member -MemberType NoteProperty -Name Firmware -Value (Get-DeployFirmwareInfo -DeviceModelGuid $deployInfo.DeviceModel.Guid)
    
    ### Get DriverPack.
    $deployInfo | Add-Member -MemberType NoteProperty -Name DriverPack -Value (Get-DeployDriverPackInfo -DeviceModelGuid $deployInfo.DeviceModel.Guid)
    
    ### Get Device information from database.
    $deployInfo | Add-Member -MemberType NoteProperty -Name Device -Value (Get-DeployDeviceInfo -HardwareInfo $deployInfo.Hardware)
    
    ### Get Device profile.
    $deployInfo | Add-Member -MemberType NoteProperty -Name Profile -Value (Get-DeployDeviceProfileInfo -DeviceGuid $deployInfo.Device.Guid)
    
    ### Get PIDOffice.
    $deployInfo | Add-Member -MemberType NoteProperty -Name PIDOffice -Value (Get-DeployDeviceIDOfficeInfo -DeviceGuid $deployInfo.Device.Guid)
    
    ### Get device Applications.
    $deployInfo | Add-Member -MemberType NoteProperty -Name Applications -Value (Get-DeployApplicationsInfo -ProfileApps $deployInfo.Profile.Applications -Device $deployInfo.Device -DeviceModel $deployInfo.DeviceModel)
    
    ### Get image.
    $deployInfo | Add-Member -MemberType NoteProperty -Name Image -Value (Get-DeployImageInfo -Guid $deployInfo.Profile.ImageGuid)
    
    ### Select Disk.
    $deployInfo | Add-Member -MemberType NoteProperty -Name Disk -Value (Get-DeployDiskInfo)
    
    ### Get Firmware type.
    $deployInfo | Add-Member -MemberType NoteProperty -Name FirmwareType -Value (Get-DeployirmwareTypeInfo)
    
    # Retur Deploy Info.
    return $deployInfo
}


function Get-DeployApplications {
    <#
        .DESCRIPTION
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        $ProfileApps,
        $Device,
        $DeviceModel
    )
    ### IMPORT MODULE
    Import-Module $DeployRoot\Modules\DeviceApplication -Force
    Import-Module $DeployRoot\Modules\DeviceModelApplication -Force
    
    $applications = @()
    $applications += $ProfileApps

    Get-DeviceApplications -DeviceGuid $Device.Guid | ForEach-Object {
        if ($applications -notcontains $_) {
            $applications += $_
        }
    }

    Get-DeviceModelApplications -DeviceModelGuid $DeviceModel.Guid | ForEach-Object {
        if ($applications -notcontains $_) {
            $applications += $_
        }
    }
    return $applications
}

function Invoke-DeployDisk {
    <#
        .FUNCTIONALITY
        Set variables: "$script:driveboot:\" ; "$script:drivesystem:\" ; $DeployWorkDir
    #>
    ### IMPORT MODULE
    Import-Module $DeployRoot\Modules\Disk -Force

    Write-Host "> Deploy-Disk" -ForegroundColor DarkMagenta

    switch ($global:deployInfo.FirmwareType) {
        "UEFI" { $local:deploydisk = Format-Disk -DiskNumber $global:deployInfo.Disk.Number -PartitionStyle GPT }
        "BIOS" { $local:deploydisk = Format-Disk -DiskNumber $global:deployInfo.Disk.Number -PartitionStyle MBR }
    }
    $script:driveboot = "$(($local:deploydisk | Where-Object { $_.FileSystemLabel -eq 'Boot' }).DriveLetter):\"
    $script:drivesystem = "$(($local:deploydisk | Where-Object { $_.FileSystemLabel -eq 'System' }).DriveLetter):\"
}
function Set-DeployWorkDir {
    <#
        .FUNCTIONALITY
        Set DeployWorkDir
    #>
    ### IMPORT MODULE

    switch ($global:DeployMode) {
        ###
        "Refresh" { 
            $script:drivesystem = "C:\"
        }

    }

    ### Set Deploy work dir.
    New-Variable -Name DeployWorkDir -Value "$($script:drivesystem)\Deploy" -Scope Global -Force

    ### Create Deploy work path.
    New-Item -Path DeployWorkDir -ItemType Directory -Force | Out-Null

    Write-Host "> Set DeployWorkDir=$($DeployWorkDir)" -ForegroundColor DarkMagenta

}
function Invoke-DeployImage {
    <#
        .FUNCTIONALITY
        Deploy Windows Image.
        Create BcdBoot store.
    #>
    ### IMPORT MODULE
    Import-Module $DeployRoot\Modules\Image -Force

    Write-Host "> Deploy-Image" -ForegroundColor DarkMagenta

    Invoke-ApplyImage -ImageFile "$($DeployRoot)$($global:deployInfo.Image.Source)" -Index $global:deployInfo.Image.ImageIndex -ApplyDir $drivesystem

    ### Crete BcdBoot Store.
    $local:result = New-BcdBootStore -DriveBoot $script:driveboot -DriveSystem $script:drivesystem -FirmwareType $global:deployInfo.FirmwareType
    #Validate
    if ($local:result -eq $true) {
        #Get-BcdEntry
    }
}
function Invoke-DeployUnattend {
    <#
        .FUNCTIONALITY
    #>
    ### IMPORT MODULE
    Import-Module $DeployRoot\Modules\Unattend -Force

    Write-Host "> Deploy-Unattend" -ForegroundColor DarkMagenta

    Build-Unattend -ComputerName $global:deployInfo.Device.ComputerName | ApplyUnattend -DriveSystem $script:drivesystem
}
function Invoke-DeployDrivers {
    <#
        .FUNCTIONALITY
        Extract driverpack to $DriveSystem\Drivers and apply on system.
    #>
    ### IMPORT MODULE
    Import-Module $DeployRoot\Modules\Drivers -Force

    Write-Host "> Deploy-Drivers" -ForegroundColor DarkMagenta

    $DriverPack = $global:deployInfo.DriverPack
    if ($null -eq $DriverPack) { continue }

    $driveworkdir = "$($script:drivesystem)\Drivers"
    
    ### Win11 utiliza driver Win10; Win10 não utiliza driver Win11.
    if ($global:deployInfo.Image.ShortName -eq 'Win11') {
        if ($DriverPack.Count -gt 1) {
            $DriverPack = $DriverPack | Where-Object { $_.OS -eq 'Win11' }
        }
    } else {
        $DriverPack = $DriverPack | Where-Object { $_.OS -eq 'Win10' }
    }

    switch ($global:DeployMode) {

        "Refresh" { 
            ### OnLine
            # check drivers before continue.
            $dest_ = New-Item -Path "C:\Drivers" -ItemType Directory -Force
            Expand-DriverPack -FilePath "$($DeployRoot)$($DriverPack.Source)" -Destination $dest_.FullName -Manufacturer $global:deployInfo.Hardware.Manufacturer
            Add-DriversOnline -DriverPath $dest_.FullName
        }
        "BareMetal" { 
            ### OffLine
            $dest_ = New-Item -Path "$($script:drivesystem)\Drivers" -ItemType Directory -Force
            Expand-DriverPack -FilePath "$($DeployRoot)$($DriverPack.Source)" -Destination $dest_.FullName -Manufacturer $global:deployInfo.Hardware.Manufacturer
            Add-DriversOffline -DriveSystem $script:drivesystem -DriverPath $dest_.FullName 
        }
    }
}
function Invoke-DeployFirmware {
    <#
        .FUNCTIONALITY
    #>
    ### IMPORT MODULE
    Import-Module $DeployRoot\Modules\Firmware -Force

    Write-Host "> Deploy-Firmware" -ForegroundColor DarkMagenta

    $Firmware = $global:deployInfo.Firmware
    if ($null -eq $Firmware) { continue }

    New-Item -Path "$($global:DeployWorkDir)\Firmware" -ItemType Directory -Force | Out-Null
    if (-not (Test-Path -Path "$($global:DeployWorkDir)\Firmware\$($Firmware.FileName)" -PathType Leaf)) {
        Copy-Firmware -Firmware $Firmware -Destination "$($global:DeployWorkDir)\Firmware"
    }

    switch ($global:DeployMode) {

        "BareMetal" {
            ###
            #Invoke-Updatefirmware
        }
        "Refresh" { 
            ###
            Invoke-Updatefirmware
        }
    }
}
function Invoke-DeployApplications {
    <#
        .FUNCTIONALITY
        Offline, Copia instaladores para disco local.
        Online, verifica se existe repo local, se não, instalado do repo da rede.
    #>
    ### IMPORT MODULES
    Import-Module $DeployRoot\Modules\Application -Force

    Write-Host "> Deploy-Applications" -ForegroundColor DarkMagenta

    switch ($global:DeployMode) {

        "Offline" {
            ###
            Copy-Applications -ListApps $global:deployInfo.Applications -Destination "$($script:drivesystem)\Deploy\Applications"
        }
        "Online" { 
            ###
            if (-not (Test-Path -Path "$($global:DeployWorkDir)\Applications" -PathType Container)) {
                Copy-Applications -ListApps $global:deployInfo.Applications -Destination "C:\Deploy\Applications"
            }
            Install-Applications -ListApps $global:deployInfo.Applications
        }
    }
}
function Invoke-DeployOffice365 {
    <#
        .FUNCTIONALITY
    #>
    ### IMPORT MODULES
    Import-Module $DeployRoot\Modules\Office365 -Force

    Write-Host "> Deploy-Office365" -ForegroundColor DarkMagenta

    switch ($global:DeployMode) {

        "Offline" {
            ###
            Copy-Item -Path "$($DeployRoot)\Sources\ODT" -Destination "$($script:drivesystem)\Deploy\ODT"  -Recurse -Force
            Build-ConfigOffice -ProductID $global:deployInfo.PIDOffice -Output "$($script:drivesystem)\Deploy\ODT\Config.xml"
        }
        "Online" { 
            ###
            if (-not (Test-Path -Path "C:\Deploy\ODT\setup.exe" -PathType Leaf)) {
                Copy-Item -Path "$($DeployRoot)\Sources\ODT" -Destination "C:\Deploy\ODT"  -Recurse -Force
            }
            if (-not (Test-Path -Path "C:\Deploy\ODT\Config.xml" -PathType Leaf)) {
                Build-ConfigOffice -ProductID $global:deployInfo.PIDOffice -Output "C:\Deploy\ODT\Config.xml"
            }
            Install-Office365
        }
    }
}
function Invoke-DeployProvisionedAppx {
    <#
        .FUNCTIONALITY
    #>
    ### IMPORT MODULES
    Import-Module $DeployRoot\Modules\Appx -Force
    Import-Module $DeployRoot\Modules\Control -Force

    Write-Host "> Deploy-ProvisionedAppx" -ForegroundColor DarkMagenta

    $blacklist = Import-JsonBlackListAppx | Where-Object { $_.OS -eq $global:deployInfo.Image.ShortName }

    switch ($global:DeployMode) {

        "Offline" {
            Remove-ProvisionedAppx -List $blacklist.Packages
        }
        "Online" { 
            Remove-ProvisionedAppx -List $blacklist.Packages -Online
        }
    }
}
function Invoke-DeployFiles {
    <#
        .FUNCTIONALITY
    #>
    ### IMPORT MODULES
    Import-Module $DeployRoot\Modules\Copy -Force

    Write-Host "> Deploy-Files" -ForegroundColor DarkMagenta

}
function Invoke-DeployFeatures {
    <#
        .FUNCTIONALITY
    #>
    ### IMPORT MODULES
    Import-Module $DeployRoot\Modules\Features -Force

    Write-Host "> Deploy-Features" -ForegroundColor DarkMagenta
    
}



<#
    .NOTES
    BareMetal, Refresh, Replace, Resume.
#>
function Invoke-BareMetal {
    <#
        .DESCRIPTION
    #>
    begin {
        ###
        Write-Host "> Invoke-BareMetal" -ForegroundColor Blue

        ###
        New-Variable -Name DeployMode -Value "BareMetal" -Scope Global -Force

        $global:deployInfo = Get-DeployInfo

        #$global:deployInfo

        #Continue?
        $private:Result = [System.Windows.MessageBox]::Show('Check information! continue?','Informations','YesNo','Question')
        if ($private:Result.value__ -eq 7) { Exit }
    }
    process {

        ###
        Invoke-DeployDisk

        ###
        Set-DeployWorkDir
        
        ###
        Invoke-DeployImage

        ###
        Invoke-DeployUnattend

        ###
        Invoke-DeployDrivers
        
        ###
        Invoke-DeployFirmware
        
        ###
        Invoke-DeployApplications
        
        ###
        Invoke-DeployOffice365
        
        ###
        Invoke-DeployProvisionedAppx
        
        ###
        Invoke-DeployFiles
         
        ###
        Invoke-DeployFeatures
        
    }
    end {
        ### Save DeployInfo.json file.
        $global:deployInfo | ConvertTo-Json -Depth 5 | Set-Content "$($script:drivesystem)\Deploy\DeployInfo.json" -Force

        ### Restart computer if running WinPE.
        if (Test-Path -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WinPE") {
            Restart-Computer -Force
        }
        ###
        ### Show Msg Finish. or send log, or  Set Finish.
    }
}

function Invoke-Refresh {
    <#
        .DESCRIPTION
    #>
    begin {
        ###
        Write-Host "> Invoke-BareMetal" -ForegroundColor Blue

        ###
        New-Variable -Name DeployMode -Value "Refresh" -Scope Global -Force

        $global:deployInfo = Get-DeployInfo

        #Continue?
        $private:Result = [System.Windows.MessageBox]::Show('Check information! continue?','Informations','YesNo','Question')
        if ($private:Result.value__ -eq 7) { Exit }
    }
    process {

        ###
        Set-DeployWorkDir
        
        ###
        Invoke-DeploySetup

        ###
        Invoke-DeployUnattend

        ###
        Invoke-DeployDrivers
        
        ###
        Invoke-DeployFirmware
        
        ###
        Invoke-DeployApplications
        
        ###
        Invoke-DeployOffice365
        
        ###
        Invoke-DeployProvisionedAppx
        
        ###
        Invoke-DeployFiles
         
        ###
        Invoke-DeployFeatures
        
    }
    end {
        ### Save DeployInfo.json file.
        $global:deployInfo | ConvertTo-Json -Depth 5 | Set-Content "$($script:drivesystem)\Deploy\DeployInfo.json" -Force

        ### Restart.
        Restart-Computer -Force
    }
}

function Invoke-Replace {
     <#
        .DESCRIPTION
    #>
    ###
    Write-Host "Invoke-Replace" -ForegroundColor Blue

    ###
    New-Variable -Name DeployMode -Value "Replace" -Scope Global -Force
}

function Invoke-Resume {
    <#
        .DESCRIPTION
    #>
    begin {
        ###
        Write-Host "Resume-Deploy" -ForegroundColor Blue
        break
        Set-Variable -Name DeployMode -Value "Online" -Scope Global
        $global:deployInfo = Get-Content "C:\Deploy\DeployInfo.json" | ConvertFrom-Json -Depth 5

    }
    process {
        ###
        #Conect to server

        ###
        Deploy-Drivers

        ###
        Deploy-Firmware

        ###
        Deploy-Applications

        ###
        Deploy-Office365

        ###
        Deploy-ProvisionedAppx

        ###
        Deploy-Files

        ###
        Deploy-Features
        # add registries
        #...  
    }
    end {
        Restart-Computer -Force
    }
}

function Invoke-Deploy {
    <#
        .DESCRIPTION
        Invoke Deploy.

        .PARAMETER BareMetal
        Este cenário ocorre quando existe um dispositivo sem nenhum SO instalado que precisa de ser implementado. 
        Este cenário também pode ser um dispositivo existente que precisa de ser apagado e reimplementado sem ter de preservar quaisquer dados existentes.

        .PARAMETER Refresh
        O processo costuma ser iniciado no sistema operacional em execução. 
        É feito o backup das configurações e dos dados do usuário, depois restaurados como parte do processo de implantação.

        .PARAMETER Replace
        A substituição de um computador é semelhante ao cenário de atualização. 
        No entanto, uma vez que estamos a substituir o dispositivo, dividimos este cenário em duas tarefas:
        Cópia de segurança do cliente antigo e implementação Bare-Metal do novo cliente.

        .PARAMETER Resume
        Continua deploy após reinicializar o dispositivo.
    #>
    [CmdletBinding(DefaultParameterSetName = 'BareMetal')]
    param(
        [Parameter(ParameterSetName="BareMetal")] [switch]$BareMetal,
        [Parameter(ParameterSetName="Refresh")] [switch]$Refresh,
        [Parameter(ParameterSetName="Replace")] [switch]$Replace,
        [Parameter(ParameterSetName="Resume")] [switch]$Resume
    )
    begin {
        ###
        if ($null -eq $global:DeployRoot) {
            New-Variable -Name DeployRoot -Value "$((Get-Item $PSScriptRoot).Parent.Parent.FullName)" -Scope Global -Force -Option ReadOnly
        }
    }
    process {
        ###
        switch ($psCmdlet.ParameterSetName) {

            "BareMetal" { 
                Invoke-BareMetal
            }
            "Refresh" { 
                Invoke-Refresh
            }
            "Replace" { 
                Invoke-Replace
            }
            "Resume" { 
                Invoke-Resume
            }
        }
    }
    end {
        ###
        return "Finish!"
    }
}


Export-ModuleMember -Function Invoke-Deploy


# SIG # Begin signature block
# MIIFlAYJKoZIhvcNAQcCoIIFhTCCBYECAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUYevSz1LXrWMEGmzNepreWUdB
# 5XCgggMiMIIDHjCCAgagAwIBAgIQONirzSpNl5FNggQlpn5yyDANBgkqhkiG9w0B
# AQsFADAnMSUwIwYDVQQDDBxQb3dlclNoZWxsIENvZGUgU2lnbmluZyBDZXJ0MB4X
# DTIzMDcxNDE1NTUxN1oXDTI0MDcxNDE2MTUxN1owJzElMCMGA1UEAwwcUG93ZXJT
# aGVsbCBDb2RlIFNpZ25pbmcgQ2VydDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCC
# AQoCggEBAL/rqq9BFlGt8bVmQ6EqY43B8W3d2b82C/QN8O37QTChQKUPws+osX1f
# tj9MPdL93WC/XEPqvUiwqPtvBS63JinOJGATsxXh/+fcHCbvJnCestdrZ36VnJJ+
# rvslUBvorv5ynfpBSZRbCuA9aK06rBXksGTbu1wLdGc3oezK7iKymqYwIilFxqz8
# FnliKSbiUWhQmpGxx9RTjZ4YP6YItETeeDMRFGBVp6wlW+qXt6fV7VfqwRkpFCNJ
# YBO9j1Cpz/WcIjoXIeorb9iY5UEsNlLzIcJV0eqJlsvvqqyK07ITKug1OK/OXsYk
# ziA9WWLmpsvv0jRQYHFwXpcx2pwmr7UCAwEAAaNGMEQwDgYDVR0PAQH/BAQDAgeA
# MBMGA1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBQ3wm3NMuMjb8eeEE5cDN2+
# 4M0FOzANBgkqhkiG9w0BAQsFAAOCAQEAEQsmQjGeMB04f0awcyggFRT988/9EN80
# bzdIWYdJFKJ3Nu2N/vKZOaSBF7AAMrNpYZGFVUgZ8wkfobw12RnH+Lz9cyt+rCSS
# TBfMyIZfoVT9sAu7NQV5cufqH82ObysqoZa3PbniXvDE+PaP1ceWje1ONmFdtr8X
# Ffkv0QFmKeH2x4cpzrJBBD58GI3XssUD2xxtHZntC98VOy0Vk4eQQZCXr42m2C3Q
# lMZby+vvm179rkn8icFkDMlQ81Im6DBSSKDP5AqWGfI5d+54ACFayHiztSS0lyl6
# OBo8+fK5kJXoTqSR2F7oh4hvFvfaBanGWmYHwcXo1yKRX2jD80/RgDGCAdwwggHY
# AgEBMDswJzElMCMGA1UEAwwcUG93ZXJTaGVsbCBDb2RlIFNpZ25pbmcgQ2VydAIQ
# ONirzSpNl5FNggQlpn5yyDAJBgUrDgMCGgUAoHgwGAYKKwYBBAGCNwIBDDEKMAig
# AoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgEL
# MQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUoCKK/wgGQkU0G6YIqMv4
# kx09lmcwDQYJKoZIhvcNAQEBBQAEggEAHhFmSqNnGiUokoAqG+89HfYszpEI2c9i
# wT+uhN6vmVX953wg37r7MnGL3Dr5sTGwkjzYsCOSfYNzYP6cqWSeUzE3CyUGinr5
# 9zapN3dVvsaKyjzaz9yt4c7/loXygBm0Rx0ZPFoPxA3lIMPpHVXMVg7BZ0piyVzV
# PbYVw9leHo8xDcDnmmVfuLWNQNlzLxCbrIH5Hm3G3Lv/X8wf2b4/5iAJBXdw9WbO
# 30BsRLlBoWoPSxUto+fZy1I7Ja5oA2Pf27MGLcN37usO/qMly4ozwLm0yZ6Za7gl
# 8t2haaRV7gs2JVSWMDBvm4WyTUwmhybgowFQofaXiw402/E0ajQZyQ==
# SIG # End signature block
