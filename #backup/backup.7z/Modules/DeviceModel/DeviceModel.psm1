<#
+----------------------------------------------------------------------------------------+
    .DESCRIPTION
    DeviceModel Module
    Created by: Gilmar Prust
    Filename: DeviceModel.psm1
+----------------------------------------------------------------------------------------+
#>

class DeviceModel {
    [string]$Guid
    [string]$Manufacturer
    [string]$Model
    [string]$Type
    
    DeviceModel([string]$Guid, [String]$Manufacturer, [String]$Model, [string]$Type) {
        $this.Guid         = $Guid
        $this.Manufacturer = $Manufacturer
        $this.Model        = $Model
        $this.Type         = $Type
    }

    DeviceModel([String]$Manufacturer, [String]$Model, [string]$Type) {
        $this.Guid         = (New-Guid).Guid
        $this.Manufacturer = $Manufacturer
        $this.Model        = $Model
        $this.Type         = $Type
    }
}

class DeviceModelList {

    static [System.Collections.Generic.List[DeviceModel]] $DeviceModels

    static [void] Initialize() {
        
        [DeviceModelList]::DeviceModels = [System.Collections.Generic.List[DeviceModel]]::new()
    }

    static [void] Add([DeviceModel]$Model) {
        
        [DeviceModelList]::DeviceModels.Add($Model)
    } 

    static [void] AddRange($Models) {
        
        $Models | ForEach-Object {

            [DeviceModelList]::DeviceModels.Add( 
                [DeviceModel]::new( 
                    $_.Guid,
                    $_.Manufacturer,
                    $_.Model,
                    $_.Type
                )
            )
        }
    }

    static [bool] Exists($Manufacturer, $Model, $Type) {

        $match = [System.Predicate[DeviceModel]] {
            param ($deviceModel)
            $deviceModel.Manufacturer -eq $Manufacturer -and 
            $deviceModel.Model -eq $Model -and 
            $deviceModel.Type -eq $Type
        }
        return [DeviceModelList]::DeviceModels.Exists($match)
    } 
}

function Import-DeviceModels {
    <##>
    Import-Module .\Modules\Control
    
    return Import-JsonDeviceModels
}

function Save-DeviceModels {
    <##>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNullOrEmpty()]
        $InputObject
    )

    Import-Module .\Modules\Control

    Save-JsonDeviceModels -Content $InputObject
}

function Add-DeviceModel {
    <#
        .DESCRIPTION
        Adiciona um item em Firmware.json.
        Este item precisa estar vinculado a um dispositivo de DeviceModels.json.
        
        .PARAMETER Manufacturer
        Especifique o modelo de dispositivo obtido de DeviceModels.json.

        .PARAMETER Model
        Especifique o item do catalogo obtido de Get-DeviceModelCatalog.

        .PARAMETER Type
        Especifique o item do catalogo obtido de Get-DeviceModelCatalog.

        .OUTPUTS
        return Object
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory, ValueFromPipeline)]
        [ValidateNotNullOrEmpty()]
        [string]$Manufacturer,
        [string]$Model,
        [string]$Type
    )

    begin {
        <##>
        [DeviceModelList]::Initialize()

        [DeviceModelList]::AddRange(@(Import-DeviceModels))
    
        <# Verifica se modelo e tipo já existe. #>
        if ([DeviceModelList]::Exists($Manufacturer, $Model, $Type)) {
            Throw "DeviceModel alread exist."
        }
    }
    process {
        <##>
        [DeviceModelList]::DeviceModels.Add(
            [DeviceModel]::new( 
                $Manufacturer, 
                $Model, 
                $Type 
            )
        )
    }
    end {
        <##>
        Save-DeviceModels -InputObject ([DeviceModelList]::DeviceModels)

        return [DeviceModelList]::DeviceModels | Select-Object -Last 1
    }
}

function Get-DeviceModels {
    <##>
    [DeviceModelList]::Initialize()

    [DeviceModelList]::AddRange(@(Import-DeviceModels))

    ### Converto to PSCustomObject.
    $DeviceModels = [DeviceModelList]::DeviceModels | ForEach-Object { 

        [PSCustomObject]@{ 
            Guid = $_.Guid;
            Manufacturer = $_.Manufacturer; 
            Model = $_.Model; 
            Type = $_.Type; 
            Firmware = $_.Firmware;
            DriverPack = $_.DriverPack;
        }
    }
    return Import-DeviceModels
}

function Get-DeviceModel {
    <##>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        $HardwareInfo
    )

    $DeviceModel = Get-DeviceModels | Where-Object { 
        $_.Manufacturer -eq $HardwareInfo.Manufacturer -and 
        $_.Model -eq $HardwareInfo.Model }

    return $DeviceModel
}


# SIG # Begin signature block
# MIIFlAYJKoZIhvcNAQcCoIIFhTCCBYECAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUYevSz1LXrWMEGmzNepreWUdB
# 5XCgggMiMIIDHjCCAgagAwIBAgIQONirzSpNl5FNggQlpn5yyDANBgkqhkiG9w0B
# AQsFADAnMSUwIwYDVQQDDBxQb3dlclNoZWxsIENvZGUgU2lnbmluZyBDZXJ0MB4X
# DTIzMDcxNDE1NTUxN1oXDTI0MDcxNDE2MTUxN1owJzElMCMGA1UEAwwcUG93ZXJT
# aGVsbCBDb2RlIFNpZ25pbmcgQ2VydDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCC
# AQoCggEBAL/rqq9BFlGt8bVmQ6EqY43B8W3d2b82C/QN8O37QTChQKUPws+osX1f
# tj9MPdL93WC/XEPqvUiwqPtvBS63JinOJGATsxXh/+fcHCbvJnCestdrZ36VnJJ+
# rvslUBvorv5ynfpBSZRbCuA9aK06rBXksGTbu1wLdGc3oezK7iKymqYwIilFxqz8
# FnliKSbiUWhQmpGxx9RTjZ4YP6YItETeeDMRFGBVp6wlW+qXt6fV7VfqwRkpFCNJ
# YBO9j1Cpz/WcIjoXIeorb9iY5UEsNlLzIcJV0eqJlsvvqqyK07ITKug1OK/OXsYk
# ziA9WWLmpsvv0jRQYHFwXpcx2pwmr7UCAwEAAaNGMEQwDgYDVR0PAQH/BAQDAgeA
# MBMGA1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBQ3wm3NMuMjb8eeEE5cDN2+
# 4M0FOzANBgkqhkiG9w0BAQsFAAOCAQEAEQsmQjGeMB04f0awcyggFRT988/9EN80
# bzdIWYdJFKJ3Nu2N/vKZOaSBF7AAMrNpYZGFVUgZ8wkfobw12RnH+Lz9cyt+rCSS
# TBfMyIZfoVT9sAu7NQV5cufqH82ObysqoZa3PbniXvDE+PaP1ceWje1ONmFdtr8X
# Ffkv0QFmKeH2x4cpzrJBBD58GI3XssUD2xxtHZntC98VOy0Vk4eQQZCXr42m2C3Q
# lMZby+vvm179rkn8icFkDMlQ81Im6DBSSKDP5AqWGfI5d+54ACFayHiztSS0lyl6
# OBo8+fK5kJXoTqSR2F7oh4hvFvfaBanGWmYHwcXo1yKRX2jD80/RgDGCAdwwggHY
# AgEBMDswJzElMCMGA1UEAwwcUG93ZXJTaGVsbCBDb2RlIFNpZ25pbmcgQ2VydAIQ
# ONirzSpNl5FNggQlpn5yyDAJBgUrDgMCGgUAoHgwGAYKKwYBBAGCNwIBDDEKMAig
# AoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgEL
# MQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUoCKK/wgGQkU0G6YIqMv4
# kx09lmcwDQYJKoZIhvcNAQEBBQAEggEAHhFmSqNnGiUokoAqG+89HfYszpEI2c9i
# wT+uhN6vmVX953wg37r7MnGL3Dr5sTGwkjzYsCOSfYNzYP6cqWSeUzE3CyUGinr5
# 9zapN3dVvsaKyjzaz9yt4c7/loXygBm0Rx0ZPFoPxA3lIMPpHVXMVg7BZ0piyVzV
# PbYVw9leHo8xDcDnmmVfuLWNQNlzLxCbrIH5Hm3G3Lv/X8wf2b4/5iAJBXdw9WbO
# 30BsRLlBoWoPSxUto+fZy1I7Ja5oA2Pf27MGLcN37usO/qMly4ozwLm0yZ6Za7gl
# 8t2haaRV7gs2JVSWMDBvm4WyTUwmhybgowFQofaXiw402/E0ajQZyQ==
# SIG # End signature block
