<#
+----------------------------------------------------------------------------------------+
    .DESCRIPTION
    Deploy Module
	Created by: Gilmar Prust
	Filename:   Deploy.psm1
+----------------------------------------------------------------------------------------+
#>

function Get-DeployInfoDeviceModel {
    <#
        .DESCRIPTION
    #>
    ### IMPORT MODULE
    Import-Module $DeployRoot\Modules\DeviceModels -Force
    
}

function Get-DeployInfo {
    <#
        .DESCRIPTION
    #>
    ### IMPORT MODULES
    Import-Module $DeployRoot\Modules\Application -Force -Verbose
    Import-Module $DeployRoot\Modules\DeviceModels -Force -Verbose
    Import-Module $DeployRoot\Modules\DriverPack -Force -Verbose
    Import-Module $DeployRoot\Modules\Office365 -Force -Verbose
    Import-Module $DeployRoot\Modules\Firmware -Force -Verbose
    Import-Module $DeployRoot\Modules\Hardware -Force -Verbose
    Import-Module $DeployRoot\Modules\Profiles -Force -Verbose
    Import-Module $DeployRoot\Modules\Control -Force -Verbose
    Import-Module $DeployRoot\Modules\Device -Force -Verbose
    Import-Module $DeployRoot\Modules\Image -Force -Verbose
    Import-Module $DeployRoot\Modules\Copy -Force -Verbose
    Import-Module $DeployRoot\Modules\Disk -Force -Verbose

    $deployInfo = New-Object -TypeName PSObject

    ### Obtem informações do hardware.
    $deployInfo | Add-Member -MemberType NoteProperty -Name Hardware -Value (Get-HardwareInfo)
    <#
        Check network state before continue.
    #>
    pause
    ### Get Device Model.
    $devicemodel = Get-DeviceModel -HardwareInfo $deployInfo.Hardware
    if ($null -eq $devicemodel) { Throw "DeviceModel not found, please use Add-DeviceModel.ps1" }
    #$devicemodel = Add-DeviceModel -HardwareInfo $hardwareinfo

    ### Get Firmware 
    $firmware = Get-Firmware -DeviceModelGuid $devicemodel.Guid
    $devicemodel | Add-Member -MemberType NoteProperty -Name Firmware -Value $firmware
    ### Get DriverPack

    $driverPack = Get-DriverPack -DeviceModelGuid $devicemodel.Guid
    $devicemodel | Add-Member -MemberType NoteProperty -Name DriverPack -Value $driverPack

    $deployInfo | Add-Member -MemberType NoteProperty -Name DeviceModel -Value $devicemodel

    ### Get Device information from database.
    $device = Get-Device -HardwareInfo $deployInfo.Hardware        
    $deployInfo | Add-Member -MemberType NoteProperty -Name Device -Value $device


    ### Get Device profile.
    $deviceprofile = Get-DeviceProfile -DeviceGuid $deployInfo.Device.Guid
    $deployInfo | Add-Member -MemberType NoteProperty -Name Profile -Value $deviceprofile

    ### Get PIDOffice
    $devicePidOffice = Get-DeviceIDOffice -DeviceGuid $deployInfo.Device.Guid
    $deployInfo | Add-Member -MemberType NoteProperty -Name PIDOffice -Value $devicePidOffice.PIDOffice

    ### Get device Applications.
    $applications = Get-DeployApplications -ProfileApps $deployInfo.Profile.Applications -Device $deployInfo.Device -DeviceModel $deployInfo.DeviceModel
    $deployInfo | Add-Member -MemberType NoteProperty -Name Applications -Value $applications

    ### Get image.
    $image = Get-Image -Guid $deployInfo.Profile.ImageGuid
    $deployInfo | Add-Member -MemberType NoteProperty -Name Image -Value $image

    ### Select Disk.
    $disk = Select-Disk
    $deployInfo | Add-Member -MemberType NoteProperty -Name Disk -Value $disk

    ### Get Firmware type.
    $firmwareType = (Import-JsonSettings).FirmwareType
    $deployInfo | Add-Member -MemberType NoteProperty -Name FirmwareType -Value $firmwareType

    return $deployInfo
}


function Get-DeployApplications {
    <#
        .DESCRIPTION
    #>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        $ProfileApps,
        $Device,
        $DeviceModel
    )

    Import-Module $DeployRoot\Modules\DeviceApplication -Verbose
    Import-Module $DeployRoot\Modules\DeviceModelApplication -Verbose
    
    $applications = @()

    $applications += $ProfileApps

    Get-DeviceApplications -DeviceGuid $Device.Guid | ForEach-Object {
        if ($applications -notcontains $_) {
            $applications += $_
        }
    }

    Get-DeviceModelApplications -DeviceModelGuid $DeviceModel.Guid | ForEach-Object {
        if ($applications -notcontains $_) {
            $applications += $_
        }
    }
    return $applications
}

function Invoke-DeployDisk {
    <#
        .DESCRIPTION
        .OUTPUTS
        [bool]
    #>
    Import-Module $DeployRoot\Modules\Disk -Force

    Write-Host "> Deploy-Disk" -ForegroundColor DarkMagenta

    switch ($global:deployInfo.FirmwareType) {
        "UEFI" { $script:DeployDisk = Format-Disk -DiskNumber $global:deployInfo.Disk.Number -PartitionStyle GPT }
        "BIOS" { $script:DeployDisk = Format-Disk -DiskNumber $global:deployInfo.Disk.Number -PartitionStyle MBR }
    }
}
function Invoke-DeployImage {
    <#
        .DESCRIPTION
        Deploy Windows Image.
        Create BcdBoot store.
    #>
    ### IMPORT MODULE
    Import-Module $DeployRoot\Modules\Image -Force

    Write-Host "> Deploy-Image" -ForegroundColor DarkMagenta

    $script:driveboot = "$(($script:DeployDisk | Where-Object { $_.FileSystemLabel -eq 'Boot' }).DriveLetter):\"
    $script:drivesystem = "$(($script:DeployDisk | Where-Object { $_.FileSystemLabel -eq 'System' }).DriveLetter):\"

    Invoke-ApplyImage -ImageFile "$($DeployRoot)$($global:deployInfo.Image.Source)" -Index $global:deployInfo.Image.ImageIndex -ApplyDir $drivesystem

    ### Crete BcdBoot Store.
    $local:result = New-BcdBootStore -DriveBoot $driveboot -DriveSystem $drivesystem -FirmwareType $global:deployInfo.FirmwareType
    #Validate
    if ($local:result -eq $true) {
        #Get-BcdEntry
    }
}
function Invoke-DeployUnattend {
    <#
        .DESCRIPTION
    #>
    ### IMPORT MODULE
    Import-Module $DeployRoot\Modules\Unattend -Force

    Write-Host "> Deploy-Unattend" -ForegroundColor DarkMagenta

    Build-Unattend -ComputerName $global:deployInfo.Device.ComputerName -Manufacturer $global:deployInfo.DeviceModel.Manufacturer | ApplyUnattend -DriveSystem $script:drivesystem

}
function Invoke-DeployDrivers {
    <#
        .DESCRIPTION
        Extract driverpack to $DriveSystem\Drivers and apply on system.
    #>
    ### IMPORT MODULE
    Import-Module $DeployRoot\Modules\Drivers

    Write-Host "> Deploy-Drivers" -ForegroundColor DarkMagenta

    $DriverPack = $global:deployInfo.DeviceModel.DriverPack
    if ($null -eq $DriverPack) { continue }

    ### Win11 utiliza driver Win10; Win10 não utiliza driver Win11.
    if ($global:deployInfo.Image.ShortName -eq 'Win11') {
        if ($DriverPack.Count -gt 1) {
            $DriverPack = $DriverPack | Where-Object { $_.OS -eq 'Win11' }
        }
    } else {
        $DriverPack = $DriverPack | Where-Object { $_.OS -eq 'Win10' }
    }

    switch ($global:DeployMode) {

        "Online" { 
            ### OnLine
            # check drivers before continue.
            $dest_ = New-Item -Path "C:\Drivers" -ItemType Directory -Force
            Expand-DriverPack -FilePath "$($DeployRoot)$($DriverPack.Source)" -Destination $dest_.FullName -Manufacturer $global:deployInfo.Hardware.Manufacturer
            Add-DriversOnline -DriverPath $dest_.FullName
        }
        "Offline" { 
            ### OffLine
            $dest_ = New-Item -Path "$($global:DriveSystem)\Drivers" -ItemType Directory -Force
            Expand-DriverPack -FilePath "$($DeployRoot)$($DriverPack.Source)" -Destination $dest_.FullName -Manufacturer $global:deployInfo.Hardware.Manufacturer
            Add-DriversOffline -DriverPath $dest_.FullName 
        }
    }
}
function Invoke-DeployFirmware {
    <#
        .DESCRIPTION
    #>
    ### IMPORT MODULE
    Import-Module $DeployRoot\Modules\Firmware

    Write-Host "> Deploy-Firmware" -ForegroundColor DarkMagenta

    $Firmware = $global:deployInfo.DeviceModel.Firmware
    if ($null -eq $Firmware) { continue }

    switch ($global:DeployMode) {

        "Offline" {
            ###
            Copy-Firmware -Firmware $Firmware -Destination "$($global:DriveSystem)\Deploy\Firmware"
        }
        "Online" { 
            ###
            if (-not (Test-Path -Path "C:\Deploy\Firmware\$($Firmware.FileName)" -PathType Leaf)) {
                Copy-Firmware -Firmware $Firmware -Destination "C:\Deploy\Firmware"
            }
            Invoke-Updatefirmware
        }
    }
}
function Invoke-DeployApplications {
    <#
        .DESCRIPTION
        Offline, Copia instaladores para disco local.
        Online, verifica se existe repo local, se não, instalado do repo da rede.
    #>
    ### IMPORT MODULES
    Import-Module $DeployRoot\Modules\Application

    Write-Host "> Deploy-Applications" -ForegroundColor DarkMagenta

    switch ($global:DeployMode) {

        "Offline" {
            ###
            Copy-Applications -ListApps $global:deployInfo.Applications -Destination "$($global:DriveSystem)\Deploy\Applications"
        }
        "Online" { 
            ###
            if (-not (Test-Path -Path "C:\Deploy\Applications" -PathType Container)) {
                Copy-Applications -ListApps $global:deployInfo.Applications -Destination "C:\Deploy\Applications"
            }
            Install-Applications -ListApps $global:deployInfo.Applications
        }
    }
}
function Invoke-DeployOffice365 {
    <#
        .DESCRIPTION
    #>
    ### IMPORT MODULES
    Import-Module $DeployRoot\Modules\Office365

    Write-Host "> Deploy-Office365" -ForegroundColor DarkMagenta

    switch ($global:DeployMode) {

        "Offline" {
            ###
            Copy-Item -Path "$($DeployRoot)\Sources\ODT" -Destination "$($global:DriveSystem)\Deploy\ODT"  -Recurse -Force
            Build-ConfigOffice -ProductID $global:deployInfo.PIDOffice -Output "$($global:DriveSystem)\Deploy\ODT\Config.xml"
        }
        "Online" { 
            ###
            if (-not (Test-Path -Path "C:\Deploy\ODT\setup.exe" -PathType Leaf)) {
                Copy-Item -Path "$($DeployRoot)\Sources\ODT" -Destination "C:\Deploy\ODT"  -Recurse -Force
            }
            if (-not (Test-Path -Path "C:\Deploy\ODT\Config.xml" -PathType Leaf)) {
                Build-ConfigOffice -ProductID $global:deployInfo.PIDOffice -Output "C:\Deploy\ODT\Config.xml"
            }
            Install-Office365
        }
    }
}
function Invoke-DeployProvisionedAppx {
    <#
        .DESCRIPTION
    #>
    ### IMPORT MODULES
    Import-Module $DeployRoot\Modules\Appx
    Import-Module $DeployRoot\Modules\Control

    Write-Host "> Deploy-ProvisionedAppx" -ForegroundColor DarkMagenta

    $blacklist = Import-JsonBlackListAppx | Where-Object { $_.OS -eq $global:deployInfo.Image.ShortName }

    switch ($global:DeployMode) {

        "Offline" {
            Remove-ProvisionedAppx -List $blacklist.Packages
        }
        "Online" { 
            Remove-ProvisionedAppx -List $blacklist.Packages -Online
        }
    }
}
function Invoke-DeployFiles {
    <#
        .DESCRIPTION
    #>
    ### IMPORT MODULES
    Import-Module $DeployRoot\Modules\Copy

    Write-Host "> Deploy-Files" -ForegroundColor DarkMagenta


    
}
function Invoke-DeployFeatures {
    <#
        .DESCRIPTION
    #>
    ### IMPORT MODULES
    Import-Module $DeployRoot\Modules\Features

    Write-Host "> Deploy-Features" -ForegroundColor DarkMagenta
    
}



<#
    .DESCRIPTION
    Inkoke methods for Deply.

    .NOTES
    BareMetal, Refresh, Replace, Resume.
#>
function Invoke-BareMetal {
    <#
        .DESCRIPTION
    #>
    begin {
        ###
        Write-Host ">- Invoke-BareMetal" -ForegroundColor Cyan
        
        ###
        New-Variable -Name DeployMode -Value "BareMetal" -Scope Global -Force
        
        $global:deployInfo = Get-DeployInfo

        #$global:deployInfo.Hardware

        #Continue?
        $private:Result = [System.Windows.MessageBox]::Show('Check information! continue?','Informations','YesNo','Question')
        if ($private:Result.value__ -eq 7) { Exit }
    }
    process {

        ###
        Invoke-DeployDisk
        
        ###
        Invoke-DeployImage

        ###
        Invoke-DeployUnattend

        ###
        Invoke-DeployDrivers
        
        ###
        Invoke-DeployFirmware
        
        ###
        Invoke-DeployApplications
        
        ###
        Invoke-DeployOffice365
        
        ###
        Invoke-DeployProvisionedAppx
        
        ###
        Invoke-DeployFiles
        
        ###
        Invoke-DeployFeatures
        
    }
    end {
        ### Save DeployInfo.json file.
        $global:deployInfo | ConvertTo-Json -Depth 5 | Set-Content "$($global:DriveSystem)\Deploy\DeployInfo.json" -Force

        ### Restart computer if running WinPE.
        if (Test-Path -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WinPE") {
            Restart-Computer -Force
        }
        ###
        ### Show Msg Finish. or send log, or  Set Finish.
    }
}

function Invoke-Refresh {
    <#
        .DESCRIPTION
    #>
    ###
    Write-Host "Invoke-Refresh" -ForegroundColor Blue

    ###
    New-Variable -Name DeployMode -Value "Refresh" -Scope Global -Force
}

function Invoke-Replace {
     <#
        .DESCRIPTION
    #>
    ###
    Write-Host "Invoke-Replace" -ForegroundColor Blue

    ###
    New-Variable -Name DeployMode -Value "Replace" -Scope Global -Force
}

function Invoke-Resume {
    <#
        .DESCRIPTION
    #>
    begin {
        ###
        Write-Host "Resume-Deploy" -ForegroundColor Blue

        Set-Variable -Name DeployMode -Value "Online" -Scope Global
        $global:deployInfo = Get-Content "C:\Deploy\DeployInfo.json" | ConvertFrom-Json -Depth 5

    }
    process {
        ###
        #Conect to server

        ###
        Deploy-Drivers

        ###
        Deploy-Firmware

        ###
        Deploy-Applications

        ###
        Deploy-Office365

        ###
        Deploy-ProvisionedAppx

        ###
        Deploy-Files

        ###
        Deploy-Features
        # add registries
        #...  
    }
    end {
        Restart-Computer -Force
    }
}

function Invoke-Deploy {
    <#
        .DESCRIPTION
        Invoke Deploy.

        .PARAMETER BareMetal
        Este cenário ocorre quando existe um dispositivo sem nenhum SO instalado que precisa de ser implementado. 
        Este cenário também pode ser um dispositivo existente que precisa de ser apagado e reimplementado sem ter de preservar quaisquer dados existentes.

        .PARAMETER Refresh
        O processo costuma ser iniciado no sistema operacional em execução. 
        É feito o backup das configurações e dos dados do usuário, depois restaurados como parte do processo de implantação.

        .PARAMETER Replace
        A substituição de um computador é semelhante ao cenário de atualização. 
        No entanto, uma vez que estamos a substituir o dispositivo, dividimos este cenário em duas tarefas main:
        cópia de segurança do cliente antigo e implementação bare-metal do novo cliente.

        .PARAMETER Resume
        Continua deploy após reinicializar o dispositivo.
    #>
    [CmdletBinding(DefaultParameterSetName = 'BareMetal')]
    param(
        [Parameter(ParameterSetName="BareMetal")] [switch]$BareMetal,
        [Parameter(ParameterSetName="Refresh")] [switch]$Refresh,
        [Parameter(ParameterSetName="Replace")] [switch]$Replace,
        [Parameter(ParameterSetName="Resume")] [switch]$Resume
    )
    begin {
        ###
        if ($null -eq $global:DeployRoot) {
            New-Variable -Name DeployRoot -Value "$((Get-Item $PSScriptRoot).Parent.Parent.FullName)" -Scope Global -Force -Option ReadOnly
        }
        
    }
    process {
        ###
        pause
        switch ($psCmdlet.ParameterSetName) {

            "BareMetal" { 
                Invoke-BareMetal
            }
            "Refresh" { 
                Invoke-Refresh
            }
            "Replace" { 
                Invoke-Replace
            }
            "Resume" { 
                Invoke-Resume
            }
        }
    }
    end {
        ###
        return "Finish!"
    }
}


Export-ModuleMember -Function Invoke-Deploy


# SIG # Begin signature block
# MIIFlAYJKoZIhvcNAQcCoIIFhTCCBYECAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUYevSz1LXrWMEGmzNepreWUdB
# 5XCgggMiMIIDHjCCAgagAwIBAgIQONirzSpNl5FNggQlpn5yyDANBgkqhkiG9w0B
# AQsFADAnMSUwIwYDVQQDDBxQb3dlclNoZWxsIENvZGUgU2lnbmluZyBDZXJ0MB4X
# DTIzMDcxNDE1NTUxN1oXDTI0MDcxNDE2MTUxN1owJzElMCMGA1UEAwwcUG93ZXJT
# aGVsbCBDb2RlIFNpZ25pbmcgQ2VydDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCC
# AQoCggEBAL/rqq9BFlGt8bVmQ6EqY43B8W3d2b82C/QN8O37QTChQKUPws+osX1f
# tj9MPdL93WC/XEPqvUiwqPtvBS63JinOJGATsxXh/+fcHCbvJnCestdrZ36VnJJ+
# rvslUBvorv5ynfpBSZRbCuA9aK06rBXksGTbu1wLdGc3oezK7iKymqYwIilFxqz8
# FnliKSbiUWhQmpGxx9RTjZ4YP6YItETeeDMRFGBVp6wlW+qXt6fV7VfqwRkpFCNJ
# YBO9j1Cpz/WcIjoXIeorb9iY5UEsNlLzIcJV0eqJlsvvqqyK07ITKug1OK/OXsYk
# ziA9WWLmpsvv0jRQYHFwXpcx2pwmr7UCAwEAAaNGMEQwDgYDVR0PAQH/BAQDAgeA
# MBMGA1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBQ3wm3NMuMjb8eeEE5cDN2+
# 4M0FOzANBgkqhkiG9w0BAQsFAAOCAQEAEQsmQjGeMB04f0awcyggFRT988/9EN80
# bzdIWYdJFKJ3Nu2N/vKZOaSBF7AAMrNpYZGFVUgZ8wkfobw12RnH+Lz9cyt+rCSS
# TBfMyIZfoVT9sAu7NQV5cufqH82ObysqoZa3PbniXvDE+PaP1ceWje1ONmFdtr8X
# Ffkv0QFmKeH2x4cpzrJBBD58GI3XssUD2xxtHZntC98VOy0Vk4eQQZCXr42m2C3Q
# lMZby+vvm179rkn8icFkDMlQ81Im6DBSSKDP5AqWGfI5d+54ACFayHiztSS0lyl6
# OBo8+fK5kJXoTqSR2F7oh4hvFvfaBanGWmYHwcXo1yKRX2jD80/RgDGCAdwwggHY
# AgEBMDswJzElMCMGA1UEAwwcUG93ZXJTaGVsbCBDb2RlIFNpZ25pbmcgQ2VydAIQ
# ONirzSpNl5FNggQlpn5yyDAJBgUrDgMCGgUAoHgwGAYKKwYBBAGCNwIBDDEKMAig
# AoAAoQKAADAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgEL
# MQ4wDAYKKwYBBAGCNwIBFTAjBgkqhkiG9w0BCQQxFgQUoCKK/wgGQkU0G6YIqMv4
# kx09lmcwDQYJKoZIhvcNAQEBBQAEggEAHhFmSqNnGiUokoAqG+89HfYszpEI2c9i
# wT+uhN6vmVX953wg37r7MnGL3Dr5sTGwkjzYsCOSfYNzYP6cqWSeUzE3CyUGinr5
# 9zapN3dVvsaKyjzaz9yt4c7/loXygBm0Rx0ZPFoPxA3lIMPpHVXMVg7BZ0piyVzV
# PbYVw9leHo8xDcDnmmVfuLWNQNlzLxCbrIH5Hm3G3Lv/X8wf2b4/5iAJBXdw9WbO
# 30BsRLlBoWoPSxUto+fZy1I7Ja5oA2Pf27MGLcN37usO/qMly4ozwLm0yZ6Za7gl
# 8t2haaRV7gs2JVSWMDBvm4WyTUwmhybgowFQofaXiw402/E0ajQZyQ==
# SIG # End signature block
